import cv2
import numpy as np
import mediapipe as mp
import math
from playsound import playsound
import threading

#Beep Function
def play_beep():
    threading.Thread(target=playsound, args=("beep.wav",), daemon=True).start()

# Mediapipe setup
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7)
mp_draw = mp.solutions.drawing_utils

#CONFIG
top_left = [100, 100]
scale = 1.2
button_base = 80
button_w, button_h = int(button_base * scale), int(button_base * scale)

# Color themes
BACKGROUND_COLOR = (40, 40, 50)
DISPLAY_COLOR = (20, 20, 30)
BUTTON_COLOR = (70, 70, 90)
BUTTON_HOVER_COLOR = (100, 100, 130)
BUTTON_TEXT_COLOR = (255, 255, 255)
BORDER_COLOR = (255, 255, 255)

# Button class
class Button:
    def __init__(self, pos, text):
        self.x, self.y = pos
        self.text = text
        self.hover = False

    def draw(self, img):
        color = BUTTON_HOVER_COLOR if self.hover else BUTTON_COLOR
        cv2.rectangle(img, (self.x, self.y), (self.x + button_w, self.y + button_h),
                      color, cv2.FILLED, lineType=cv2.LINE_AA)
        cv2.rectangle(img, (self.x, self.y), (self.x + button_w, self.y + button_h),
                      BORDER_COLOR, 2, lineType=cv2.LINE_AA)

        font_scale = 0.6 * (button_h / 40)
        thickness = 2 if button_h < 100 else 3
        text_size = cv2.getTextSize(self.text, cv2.FONT_HERSHEY_SIMPLEX, font_scale, thickness)[0]
        text_x = self.x + (button_w - text_size[0]) // 2
        text_y = self.y + (button_h + text_size[1]) // 2
        cv2.putText(img, self.text, (text_x, text_y),
                    cv2.FONT_HERSHEY_SIMPLEX, font_scale, BUTTON_TEXT_COLOR, thickness, lineType=cv2.LINE_AA)

    def is_hover(self, px, py):
        return self.x < px < self.x + button_w and self.y < py < self.y + button_h

# Calculator buttons
keys = [['7', '8', '9', '/'],
        ['4', '5', '6', '*'],
        ['1', '2', '3', '-'],
        ['C', '0', '=', '+'],
        ['sqrt', '^', '(', ')']]

buttons = []

def create_buttons():
    buttons.clear()
    for i in range(len(keys)):
        for j in range(4):
            x = top_left[0] + j * (button_w + 10)
            y = top_left[1] + i * (button_h + 10) + 80
            buttons.append(Button((x, y), keys[i][j]))

create_buttons()

# Equation string
equation = ""

# Webcam
cap = cv2.VideoCapture(0)

while True:
    ret, img = cap.read()
    if not ret:
        break
    img = cv2.flip(img, 1)
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    results = hands.process(img_rgb)

    # Draw calculator background
    calc_w = 4 * button_w + 30
    calc_h = len(keys) * button_h + 30 + 80
    cv2.rectangle(img, tuple(top_left),
                  (top_left[0] + calc_w, top_left[1] + calc_h),
                  BACKGROUND_COLOR, cv2.FILLED)

    # Display area
    cv2.rectangle(img,
                  (top_left[0] + 10, top_left[1] + 10),
                  (top_left[0] + calc_w - 10, top_left[1] + 70),
                  DISPLAY_COLOR, cv2.FILLED)
    
    display_equation = equation.replace("**", "^").replace("math.sqrt", "sqrt")
    font_scale_display = 1.2 * (button_h / 60)
    cv2.putText(img, display_equation, (top_left[0] + 20, top_left[1] + 55),
                cv2.FONT_HERSHEY_SIMPLEX, font_scale_display, (0, 255, 0), 3, lineType=cv2.LINE_AA)

    # Reset hover
    for button in buttons:
        button.hover = False

    hovered_button = None

    # Hand detection
    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            mp_draw.draw_landmarks(img, hand_landmarks, mp_hands.HAND_CONNECTIONS)

            lm = hand_landmarks.landmark
            h, w, _ = img.shape
            index_tip = int(lm[8].x * w), int(lm[8].y * h)
            cv2.circle(img, index_tip, 10, (255, 0, 255), cv2.FILLED)

            for button in buttons:
                if button.is_hover(*index_tip):
                    button.hover = True
                    hovered_button = button
                    break

    # Draw buttons
    for button in buttons:
        button.draw(img)

    # Show calculator
    cv2.imshow("Floating Virtual Calculator", img)
    key = cv2.waitKey(1)

    # Controls
    if key == ord('q'):
        break
    elif key == ord('a'):
        top_left[0] -= 10
        create_buttons()
    elif key == ord('d'):
        top_left[0] += 10
        create_buttons()
    elif key == ord('w'):
        top_left[1] -= 10
        create_buttons()
    elif key == ord('s'):
        top_left[1] += 10
        create_buttons()
    elif key == ord('+'):
        scale += 0.1
        button_w, button_h = int(button_base * scale), int(button_base * scale)
        create_buttons()
    elif key == ord('-') and scale > 0.5:
        scale -= 0.1
        button_w, button_h = int(button_base * scale), int(button_base * scale)
        create_buttons()

    # Press Enter to select button
    elif key == 13 and hovered_button:
        symbol = hovered_button.text
        play_beep()  # 🔊 Beep when pressed

        if symbol == 'C':
            equation = ''
        elif symbol == '=':
            try:
                safe_eq = equation.replace('^', '**')
                if 'sqrt' in safe_eq:
                    safe_eq = safe_eq.replace('sqrt', 'math.sqrt')
                equation = str(eval(safe_eq, {"math": math}))
            except:
                equation = 'Error'
        elif symbol == 'sqrt':
            equation += 'sqrt('
        else:
            equation += symbol

cap.release()
cv2.destroyAllWindows()
