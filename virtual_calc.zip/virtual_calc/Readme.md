Floating Virtual Calculator with Hand Gesture Control
Project Overview
This project creates a floating virtual calculator that can be controlled using hand gestures. It utilizes the Mediapipe library for hand tracking and OpenCV for computer vision. The calculator features basic arithmetic operations (addition, subtraction, multiplication, division), as well as advanced functions like square root and power. It also includes button press sounds for an interactive experience. The position and size of the calculator can be easily controlled on the screen.

Key Features:
Hand Gesture Control: Use hand gestures to interact with the calculator.

Floating Calculator: The calculator can be moved and resized on your screen.

Arithmetic Operations: Perform addition, subtraction, multiplication, and division.

Advanced Operations: Calculate square roots and powers.

Button Press Sounds: Get feedback with sounds when buttons are pressed.

Requirements
Before running the project, you need to install the following Python dependencies:

mediapipe

opencv-python

numpy

pygame (for sound effects)

You can install them via the requirements.txt file or manually.

Installation
Clone the repository or download the project files.

Set up a Python virtual environment (optional, but recommended):

bash
Copy
Edit
python -m venv venv
Activate the virtual environment:

On Windows:

bash
Copy
Edit
venv\Scripts\activate
On MacOS/Linux:

bash
Copy
Edit
source venv/bin/activate
Install dependencies from the requirements.txt file:

bash
Copy
Edit
pip install -r requirements.txt
Or manually install the required libraries using:

bash
Copy
Edit
pip install mediapipe opencv-python numpy pygame
Usage
Connect your webcam and ensure it is properly configured.

Run the application:

bash
Copy
Edit
python calculator.py
The calculator will appear on your screen. You can use your hand to control the buttons on the calculator.

Controls
Move the calculator:

Press 'w' to move up.

Press 's' to move down.

Press 'a' to move left.

Press 'd' to move right.

Resize the calculator:

Press '+' to increase the size.

Press '-' to decrease the size.

Interact with the calculator:

Use your index finger to hover over buttons. The button will change color when hovered.

To press a button, place your finger directly over it.

'C': Clears the current equation.

'=': Evaluates and shows the result of the equation.

'√': Computes the square root of the number.

'^': Raises a number to a power (e.g., 2^3).

Exit the program:

Press 'q' to quit the application.